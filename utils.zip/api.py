""" Api"""
from flask import Blueprint, jsonify, request,session,abort
import utils
import bd

bp_api = Blueprint('api', __name__)

@bp_api.route('/services')
def api_services():
    """Les services"""
    offset = int(request.args.get("offset", 0))
    limite = int(request.args.get("limite", 6))

    with bd.creer_connexion() as conn:
        services = bd.get_services_pagination(conn, offset, limite)
        for service in services:
            service["image_path"] = utils.get_image_path(service["id_service"])

            service["peut_reserver"] = False
            service["peut_supprimer"] = False

            identifiant = session.get("identifiant")

            if identifiant:
                est_prop = bd.verifier_proprietaire_service(
                    conn,
                    service["id_service"],
                    identifiant
                )

                if est_prop:
                    service["peut_supprimer"] = True
                else:
                    service["peut_reserver"] = True

                if session.get("role") == "admin":
                    service["peut_supprimer"] = True

    return jsonify(services)


@bp_api.route('/suggestion-recherche')
def suggestion_rechercher():
    """Sugestion de recherche"""
    query = request.args.get('query', '').strip().lower()

    if not query or len(query) < 2:
        return jsonify([])

    with bd.creer_connexion() as conn:
        resultat = bd.get_api_recherche(conn, query)

    return jsonify(resultat)

@bp_api.route('/verifier-courriel')
def verifier_courriel():
    """ Vérification du courriel """
    courriel = request.args.get('courriel')

    with bd.creer_connexion() as conn:
        user_doublon = bd.verifie_doublon_courriel(conn, courriel)

    return jsonify({"existe": user_doublon})

