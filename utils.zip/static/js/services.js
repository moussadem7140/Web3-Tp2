/*global envoyerRequeteAjax*/

"use strict";

let offset = 0;
let limite  = 6;
let bloc   = 3;
let enChargement = false;
let fin = false;

/**
 * Création d'une carte service
 */
function creerCarteService(service) {
    const col = document.createElement("div");
    col.className = "col-md-4 mb-3";

    col.innerHTML = `
        <div class="card shadow-sm h-100">
            <img src="${service.image_path}" class="card-img-top" alt="Image service">

            <div class="card-body">
                <h5 class="card-title">${service.titre}</h5>
                <p class="card-text">
                    <strong>Catégorie :</strong> ${service.nom_categorie}<br>
                    <strong>Localisation :</strong> ${service.localisation}
                </p>

                <a href="/details_service/${service.id_service}"
                   class="btn btn-primary">Voir détails</a>
            </div>
        </div>
    `;
    return col;
}

/**
 * Charger services via API
 */
function chargerServices() {
    if (enChargement || fin) return;

    enChargement = true;
    document.getElementById("loader").classList.remove("d-none");

    envoyerRequeteAjax(
        `/api/services?offset=${offset}&limite=${limite}`,
        (reponse) => {
            const services = JSON.parse(reponse);
            const conteneur = document.getElementById("conteneur-services");

            if (services.length === 0) {
                fin = true;
                document.getElementById("fin-message").classList.remove("d-none");
                document.getElementById("loader").classList.add("d-none");
                return;
            }

            services.forEach(service => {
                conteneur.appendChild(creerCarteService(service));
            });

            offset += services.length;
            limite = bloc;

            enChargement = false;
            document.getElementById("loader").classList.add("d-none");
        }
    );
}

function gererDefilement() {
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight * 0.90) {
        chargerServices();
    }
}

function initialisation() {
    window.addEventListener("scroll", gererDefilement);
    chargerServices();
}

window.addEventListener("load", initialisation);
